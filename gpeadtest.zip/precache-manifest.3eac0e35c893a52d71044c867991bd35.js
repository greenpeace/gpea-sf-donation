self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2b9e1f0525646f4978c65593afe2746c",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/index.html"
  },
  {
    "revision": "5470f8e11be847a71030",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/css/2.77b46fe1.chunk.css"
  },
  {
    "revision": "d3f49a9aa88115f5d43d",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/css/main.32ec8584.chunk.css"
  },
  {
    "revision": "5470f8e11be847a71030",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/js/2.f9f85fd1.chunk.js"
  },
  {
    "revision": "d3f49a9aa88115f5d43d",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/js/main.3824ca54.chunk.js"
  },
  {
    "revision": "33509c6f1abe09f8e84c",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/js/runtime-main.471062de.js"
  },
  {
    "revision": "034baa2c90687fad501b83e225f3728f",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Bold.034baa2c.woff"
  },
  {
    "revision": "68a71533d08ff9251d6f179043a4781b",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Bold.68a71533.woff2"
  },
  {
    "revision": "7b6ae28b116debe909b3fec84b310468",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-BoldItalic.7b6ae28b.woff"
  },
  {
    "revision": "dba3843e5b62ac3c2d9637a98f2207f4",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-BoldItalic.dba3843e.woff2"
  },
  {
    "revision": "490fd008e87efd93f09b27cc298402d3",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Italic.490fd008.woff"
  },
  {
    "revision": "afa7774ce458bd2fc11c0f838f95a920",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Italic.afa7774c.woff2"
  },
  {
    "revision": "49c5f0d3823d5417274ec49fe9d702d7",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Light.49c5f0d3.woff"
  },
  {
    "revision": "c9505072b839823249fbfbf0c3e31ef8",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Light.c9505072.woff2"
  },
  {
    "revision": "13eed833d3d7ff2ae1b85ac45b13a3d9",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-LightItalic.13eed833.woff"
  },
  {
    "revision": "676a9c306dd2390c45ec0d0b28e51a6a",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-LightItalic.676a9c30.woff2"
  },
  {
    "revision": "8621cf5a8eb1acfacd002232c95d85ed",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Regular.8621cf5a.woff"
  },
  {
    "revision": "aa41afdaceb8b78c56529555448bcf44",
    "url": "https://api.greenpeace.org.hk/2020/sf-donation/static/media/SalesforceSans-Regular.aa41afda.woff2"
  }
]);